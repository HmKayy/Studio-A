// Define a case class to represent a single row in the CSV file
case class VideoGame(name: String, year: Int, genre: String, naSales: Double, euSales: Double, globalSales: Double)
